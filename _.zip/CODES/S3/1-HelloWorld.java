package introduction;

public class HelloWorld {

	public static void main(String[] args) {
		// This is my 1st Java Program
		/*
		 * This
		 * is
		 * my
		 * 1st Java Program
		 */
		
		System.out.println("Hello Word!");
	}
}