package oopconcepts;

public class Car {
	// color
	private String color;
	// make
	private String make;
	// model
	private String model;
	// year
	private int year;
	

	public void increaseSpeed() {
		System.out.println("Increasing the speed");
	}

}
