package automobile;

public interface BMWCarsInterface {
	
	public void headsUpNavigation();

}
